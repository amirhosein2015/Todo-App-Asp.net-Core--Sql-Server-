﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace TodoApp.Models // 
{

    //کلاس جدید برای کاربران// 
    //کلاس پیش‌ فرض مدیریت کاربران//
    public class ApplicationUser : IdentityUser
    {
        //قابلیت سفارشی‌سازی در آینده//
        //public string FirstName { get; set; }//
    }
}
